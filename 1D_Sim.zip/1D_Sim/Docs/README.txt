1. Installation:

Just add the 'Subfunctions' folder to your matlab path.

2. Code structure:

Simulations are run by creating 'Simulation' files, which are found in the 
'Simulations' folder. See 'runfile_template.m' for more description, which
is a blank template for creating new simulation files.

Each simulation file loads the default settings from 'kf1d_default_settings.m'
file. Avoid editing this as the behaviour of all simulations will change. 
Instead, define simulation specific settings in each simulation file.

Each simualtion file will run 'kf1d_run_main.m' which is the main run file.
In each iteration of the loop, a virtual animal moves at a constant speed
up and down a 1D linear track. The most important variables are:

GC : contains the firing rates of all the GCs at time t
PC : contains the firing rates of all the PCs at time t
W  : contains the current PC->GC weights

For plotting purposes, the simulation also stores GC_PI (the intermediate
distribution following the movement update) and P_PI (the distribution
used to perform the movement distribution).

3. Demos:

There are three demos. See DESCRIPTION_OF_DEMOS.txt for details.