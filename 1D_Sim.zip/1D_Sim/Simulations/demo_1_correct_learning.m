%% 1. Demo correct PC-GC weights
%
% Run the simulation with perfect PI, perfect animal tracking and no sensory input
% 
% No noise in the movement update (variance of movment update gaussian = 0)
% and no noise in the estimate of the current animal's movement since time
% t-1.
%
% In this simulation there is no sensory update. The PC-GC weights are
% still learned, but offline, so they don't affect the current estimate.
% This simulation is therefore a demo of what the 'correct' PC-GC weights
% should eventually end up looking like.

% Make copies of this template and add ccustom simulation specific
% settings. The simulation specific settings will overwrite the setttings
% stored in the default settings. You can also edit the default settings,
% but be aware that it will affect all simulations.

%% Some pre-amble
clearvars; close all; clc
set(0,'DefaultFigureWindowStyle','normal','DefaultFigureVisible', 'on')

%% Load the default settings
SET = kf1d_default_settings();

%% Overwrite settings here

SET.noisy_PI_update  = 0;   % No noise in the PI update
SET.perfect_tracking = 1;   % No noise in the estimate of movement
SET.sensory_update    = 0;   % Learn the PC-GC weights offline according to perfect PI 
SET.plot_gap         = 100;   % How often (iterations) to update the plots

%% Run the main script
kf1d_run_main;