%% 3. Unstable sticking point at low speed
%
% Same parameters as Demo 2 except here I have lowered the speed. Now,
% instead of converging, the weights seem to become stable in an erroneous
% configuration.
%
% My intuition about what is happening here is as follows. Since the animal
% is moving very slow, learning occurs to the PCs encountered at the start
% of the track such that their input quickly becomes strong. Since they
% have a relatively broad receptive field, they are constantly stimulating
% the GCs at the position in which they first learned associations - i.e.
% at the start. Therefore, at timestep 2, the PI estimate wants to advance
% the GC distribution, but the sensory estimate corrects it to the position
% at the first location. So, the GC distribution gets stuck at its initial
% position (or at least, it gets dragged backwards so that it doesnt keep
% up with the actual animal movement).
%
% My intuition suggests that with every successive sweep, the difference in
% the PI and sensory estimate should shift the weight matrix a little bit
% such that over time, the weights should converge to the correct values.
% But, it seems that they don't.
%
% Make copies of this template and add ccustom simulation specific
% settings. The simulation specific settings will overwrite the setttings
% stored in the default settings. You can also edit the default settings,
% but be aware that it will affect all simulations.

%% Some pre-amble
clearvars; close all; clc
set(0,'DefaultFigureWindowStyle','normal','DefaultFigureVisible', 'on')

%% Load the default settings
SET = kf1d_default_settings();

%% Overwrite settings here

% e.g. SET.speed = 10;
SET.SIG_PC = 1e-3;
SET.SIG_R  = 1e-3;
SET.LR = 1e-3;
SET.plot_gap = 53;
SET.speed = 0.01;

%% Run the main script
kf1d_run_main;