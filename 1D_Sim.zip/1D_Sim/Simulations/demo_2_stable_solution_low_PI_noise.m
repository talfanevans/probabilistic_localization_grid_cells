%% 2. Stable solution with low PI noise
%
% Here, the PI noise is low enough that the animal can make it to the end
% of the track without incorporating significant error in its position
% estimate (but still some). Weights are erratic to begin with but converge
% to stable values over time (they line up with the 'ideal' red dotted
% lines).
%
% Make copies of this template and add ccustom simulation specific
% settings. The simulation specific settings will overwrite the setttings
% stored in the default settings. You can also edit the default settings,
% but be aware that it will affect all simulations.

%% Some pre-amble
clearvars; close all; clc
set(0,'DefaultFigureWindowStyle','normal','DefaultFigureVisible', 'on')

%% Load the default settings
SET = kf1d_default_settings();

%% Overwrite settings here

% e.g. SET.speed = 10;
SET.SIG_PC = 1e-3;
SET.SIG_R  = 1e-3;
SET.LR = 1e-3;
SET.plot_gap = 53;
SET.speed = 0.051;

%% Run the main script
kf1d_run_main;