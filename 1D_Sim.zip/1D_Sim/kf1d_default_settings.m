% Default settings

function SET = kf1d_default_settings()

%% Simulation options
SET.perfect_tracking = 0;                                                  % (logical) Option to turn ON/OFF noise in movement update
SET.sensory_update   = 1;                                                  % (logical) Option to turn INCLUDE/NOT_INCLUDE the sensory update step (i.e. if 0, estimate proceeds according to movement update only)
SET.noisy_PI_update  = 1;                                                  % (logical) Include noise in the PI update or not

SET.plot_gap = 1;                                                          % Update plots every plot_gap iterations
 
SET.plothist = 1;                                                          % How far back to plot the stats histories

%% Simulation parameters
SET.T = 1e5;                                                               % Run time (nuber of iterations)

SET.X = 1;                                                                 % Length of 1D track

SET.speed = 0.01;                                                          % Speed of movement across track (units/iteration)

SET.NGC = 1000;                                                            % ! Must be even integer ! Number of grid cells
SET.SIG_Q = 10.^-3.5;                                                      % Variace of gaussian noise in movement estimate
SET.L = 0.2;                                                               % Grid scale

SET.NPC = 500;                                                             % Number of place cells
SET.FMAX_PC = 1;                                                           % Max firing rate of PCs
SET.SIG_PC = 1e-4;                                                         % Tuning width of PCs (variance describing the Gaussian tuning shape)
SET.SIG_R = SET.SIG_PC;                                                    % Variance in Gaussian noise associated with sensory estimate (we set to be same as tuning width)

SET.LR = 1e-2;                                                             % Learning rate

end