%% Run file template
%
% Make copies of this template and add ccustom simulation specific
% settings. The simulation specific settings will overwrite the setttings
% stored in the default settings. You can also edit the default settings,
% but be aware that it will affect all simulations.

%% !! Some pre-amble !! (Do not edit)
clearvars; close all; clc
set(0,'DefaultFigureWindowStyle','normal','DefaultFigureVisible', 'on')

%% !! Load the default settings !! (Do not edit)
SET = kf1d_default_settings();

%% ** Overwrite settings here **

% e.g. SET.speed = 10;

%% !! Run the main script !! (Do not edit)
kf1d_run_main;