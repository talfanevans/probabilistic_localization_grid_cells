% Update GC firing (estimates of position)
%
% Inputs:
%
% DX_PI           : (Scalar)     Noisy estimate of agent movement at time t
% GC              : ([1,N_{GC}]) Vector describing the current activity of all grid cells (current state distribution)
% PC_MEAS         : ([1,N_{PC}]) Vector describing current firing rates of all place cells
% MU_GC           : ([1,N_{GC}]) Vector describing spatial offsets of each GC
% SIG_Q           : ([1,N_{GC}]) Vector describing variance associated with each movement
% L               : (Scalar)     Grid scale (distance between grd fields)
% noise_PI_update : (logical)    Option to turn ON/OFF noise in movement update
% sensory_update  : (logical)    Option to turn INCLUDE/NOT_INCLUDE the sensory update step (i.e. if 0, estimate proceeds according to movement update only)

% Outputs:
%
% GC     : ([1,N_{GC}]) Vector describing new GC activity (curent state distribution)
% GC_OLD : ([1,N_{GC}]) "      "          old "  "        "       "     "
% GC_PI  : ([1,N_{GC}]) "      "          intermediate GC activity after movement update but before sensory update
% P_PI   : ([1,N_{GC}]) Vector describing the movement distribution used to perform the movement update


function [GC,GC_OLD,P_PI,GC_PI] = kf1d_update_estimates(DX_PI,GC,PC_MEAS,MU_GC,SIG_Q,L,noise_PI_update,sensory_update)

% Intialise
NGC = length(MU_GC);
GC_OLD = GC;

% Compute the distribution used to perform the movement (PI) update
if noise_PI_update
    P_PI = kf1d_wrapped_gaussian(DX_PI,MU_GC,SIG_Q,L);
else
    P_PI = kf1d_wrapped_gaussian(DX_PI,MU_GC,0.01*ones(1,NGC),L); P_PI = double(P_PI==max(P_PI));
end
P_PI = P_PI/sum(P_PI);                                                     

% Compute the PI update
P_PId = [P_PI,P_PI,P_PI];                                                  % Wrap the distribution to make sure we don't get edge effects
GC_PI = conv(GC,P_PId,'same');                                             % Convolve the movement and current distributions to perform the movement update

GC_PI = GC_PI / sum(GC_PI);                                                % Normalise the intermediate estimate distribution

% Compute the mesaurement update
if sensory_update
    GC = GC_PI.*PC_MEAS(:)';                                               % Product of movement and sensory estimate distributions performs the sensory update
else
    GC = GC_PI;
end

% Normalise
GC = GC / sum(GC);                                                      

end