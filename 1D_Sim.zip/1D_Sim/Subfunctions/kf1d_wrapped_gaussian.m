% 1D Wrapped Gaussian
%
% F is a matrix with outputs of dimensions: [NX,NC]
%
% where NX and NC are the number of query points and cells, respectively
%
function F = kf1d_wrapped_gaussian(X,MU,SigSquared,L,NW)

% Defaults
if nargin<5; NW = 100; end % Number of wraps

% Check inputs
if all(size(MU)>1) ; error('MU must be a vector.\n');  end
if all(size(SigSquared)>1); error('SIG must be a vector.\n'); end
if all(size(L)>1)  ; error('L must be a vector.\n');   end
if ~all(size(SigSquared)==size(MU)==size(L)); error('SIG and MU and L must have the same length.\n'); end

% Wrap the coordinates
X = mod(X+L/2,L)-L/2; 

% Initialise the parameters
NX = length(X); % Number of queries
NC = length(MU); % Number of cells

W   = permute(repmat((-NW:NW)',[1,NX,NC]),[2,3,1]);
X   = repmat(X(:),[1,NC,size(W,3)]);
SigSquared = repmat(SigSquared(:)',[NX,1,2*NW+1]);
MU  = repmat(MU(:)',[NX,1,2*NW+1]);

% Main
F = sum((1./sqrt(2*pi*SigSquared)) .* exp(-((X-(MU+L*W)).^2)./(2*SigSquared)),3);

end