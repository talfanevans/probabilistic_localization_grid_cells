%% 1D simulation of full 2d simulation

%% 1. Copy the settings into the workspace
% So we don't always have
% to type SET.parameter...
FN = fieldnames(SET);
for fn=1:length(FN); eval([FN{fn},'=SET.',FN{fn}]); end

%% 2. Initialise
dir = 1;                                                                   % Direction of travel (1 is right to left)
xnew = 0; xold = 0;                                                        % Starting position

% Grid cells
MU_GC = linspace(-L/2,L/2,NGC+1); MU_GC = MU_GC(1:end-1);                  % Spatial offsets of GCs
SIG_Q = SIG_Q*ones(1,NGC);                                                 % Variance of GC gaussians (tuning widths)
GC = kf1d_wrapped_gaussian(xnew,MU_GC,SIG_Q,L);                            % Intialise firing of GCs
GC = GC/sum(GC);                                                           % Normalise such that the total firing = 1 (the GCs represent a prob. distribution)

% Place cells
MU_PC = linspace(0,X,NPC);                                                 % Preferred firing locations of PCs
PC = zeros(1,NPC);                                                         % Initialise firing of PCs     
TH = zeros(1,NPC);                                                         % Learning thhreshold for BCM rule (one for each PC)
SIG_R = SIG_R*ones(1,NPC);                                                 % Noise in sensory estimate
SIG_PC = SIG_PC*ones(1,NPC);                                               % Tuning width of PC (set as the same as the noise associated with each estimate)

% PC->GC weights
W = ones(NGC,NPC); W = W/NPC/NGC;                                          % Initialise weights
%W = 10*rand(NGC,NPC); W = W/NPC/NGC; % PC->GC Weights

% Stats
err = zeros(1,T);                                                          % Keep track of the error between the actual and estimated location at each time point
meanerr = zeros(1,T);                                                      % Cumulative mean error

% Plotting
YLIM_GC = [0,max(GC)];                        

% Functions
wrap = @(x) mod(x+L/2,L)-L/2;                                              % Wrap real-space to 1D grid cell space
circ_dist = @(x1,x2) min([mod(x1-x2,L),mod(x2-x1,L)]);                     % Circular distance between two points in 1D grid cell space

%% 3. Run main
for t=1:T
    
    clc; fprintf('t=%i/%i\n',t,T)
    
    %% 4a. Generate new true coordinate
    xnew = xold + dir*speed;                                                  % Increment the true agent position
    if xnew>X; dir=-1; xnew=2*X-xnew; elseif xnew<0; dir=1; xnew=xnew*-1; end % Correct the position if it goes out of bounds and change the direction
    dx = xnew-xold;                                                           % Get the distance moved
    xold = xnew;
    
    %% 4b. Add noise to get the estimate of position moved
    noise = sqrt(SIG_Q(1))*speed*randn();                                  % Generate noise associated with movement update that is proportional to the amount moved
    if perfect_tracking; dx_pi=dx; else; dx_pi = dx + noise; end           % Get noisy estimate (unless we're running with perfect path integration)
    
    %% 4c. Take a noisy measurement from the PCs
    if perfect_tracking                                                    % Noisy estimate of position is different for each PC
        z=xnew*ones(1,NPC); 
    else
        z = xnew + sqrt(SIG_R).*randn(1,NPC);
    end 
    PC = kf1d_get_pc_firing(z,MU_PC,SIG_PC,FMAX_PC);                       % Get the PC firing at time t
    PC = diag(PC)';                                                        % The above calculates the response of each PC to all of the coordinates, we only want the response of each PC to one of the coordinates (this is an inefficient method I know...)
    PC_MEAS = kf1d_get_measurement_from_sensory(PC,W);                     % Translate the raw PC firing into a 'measurement' in grid cell space
    
    %% 4d. Update the position estimates
    [GC,GC_OLD,P_PI,GC_PI] = kf1d_update_estimates(dx_pi,GC,PC_MEAS,MU_GC,SIG_Q,L,noisy_PI_update,sensory_update);
    
    %% 4d. Update the PC->GC connections
    [W,TH] = kf1d_update_sensory_connections(PC,GC,TH,LR,W);
    
    %% 4e. Calculate some stats
    xwrapped     = wrap(xnew);                                             % Wrapped position of agent in grid cell space
    xwrapped_est = MU_GC(find(GC==max(GC),1)); %#ok<FNDSB>                 % Get the current estimate by finding thee grid cell with highest firing rate (could interpolate for more accuracy but...)
    
    err(t)     = circ_dist(xwrapped,xwrapped_est);                         % Store the current error as the circular distance between these two estimates
    meanerr(t) = mean(err(1:t));                                           % Running mean error
    
    %% 4f. Update plot
    if (mod(t,plot_gap)==1) || (plot_gap==1)
        M = 5; N = 3; p = 1; MS = 2; LW = 1; LT = 'o-';
        
        % Current position of the agent along a 1D track
        subplot(M,N,p); p=p+1; hold off;
        plot([0,X],[0,0],'r-','LineWidth',LW); hold on;
        scatter(xnew,0,10*MS,'x'); ylim([-0.5,0.5]);
        xlim([0,X]); ylabel('Position'); set(gca,'YTick',[],'XTick',0:0.2:1)
        title('Current position of agent')
        
        % Weight between Grid Cells and Place Cells
        subplot(M,N,p); p=p+1;
        imagesc(W); xlabel('PC#'); hold on;
        for i = 1:2:2*(round(X/L)+1)
            plot([NPC*L/X/2*(i-2),NPC*L/X/2*i],[1,NGC],'r--','LineWidth',2)
        end
        xlim([1,NPC]); ylim([1,NGC])
        ylabel('GC#'); 
        title({sprintf('Max(WEIGHTS)=%.2e',max(W(:))),'(Red lines indicate correct correspondence','of PC to GC location)'});
        p=p+1;
        
        p=p+1; % Skip a plot
        
        % Movement update
        subplot(M,N,p); p=p+1; hold off;
        plot(MU_GC,GC_OLD,LT,'MarkerSize',MS); hold on;                    % Previous distribution
        plot(MU_GC,P_PI  ,'--','MarkerSize',MS);                           % Movement distribution
        plot(MU_GC,GC_PI ,LT,'MarkerSize',MS);                             % Intermediate distribution
        plot([xwrapped,xwrapped],[0,YLIM_GC(2)],'g--','LineWidth',LW)      % True positions of agent
        legend({'G_{t-1}','Movement distribution','GC_{PI}','True agent position'},'Position',[.6547    0.6662    0.1914    0.0624]); xlim([min(MU_GC),max(MU_GC)]); ylim(YLIM_GC)
        title('Movement update')
        p=p+1;
        
        % Current PC activity
        subplot(M,N,p); p=p+1; hold off;
        a=scatter(MU_PC,PC,MS,'filled');
        ylabel('PC'); xlim([0,X]); xlabel('Real Space'); ylim([0,max(PC)])
        title('PC activity')
        
        % Sensory update and current distribution
        subplot(M,N,p); p=p+1; hold off;
        plot(MU_GC,PC_MEAS,LT,'MarkerSize',MS); hold on;                   % Sensory input distribution
        plot(MU_GC,GC_PI,LT,'MarkerSize',MS);                              % Intermediate distribution
        plot(MU_GC,GC,LT,'MarkerSize',MS);                                 % Final distribution (cuurrent estimate)
        plot([xwrapped,xwrapped],[0,YLIM_GC(2)],'g--','LineWidth',LW)      % True position of agent
        legend({'PC_{MEAS}','GC_{PI}','GC_{NEW}','True agent position'},'Position',[0.6570    0.4878    0.1932    0.0728]); xlim([min(MU_GC),max(MU_GC)]); ylim(YLIM_GC)
        title('Sensory update and current estimate')
        p=p+1;
        
        p=p+1; % Skip a plot
        
        % Current distribution and estimates of position
        subplot(M,N,p); p=p+1; hold off;
        plot(MU_GC,GC,LT,'MarkerSize',MS); hold on;
        b=plot(xwrapped_est,0,'x','MarkerSize',10*MS);
        c=plot(xwrapped,0,'x','MarkerSize',10*MS);
        plot([xwrapped,xwrapped],[0,max(GC)],'g--','LineWidth',LW)
        legend([b,c],{'Est','True'},'Position',[0.6639    0.3344    0.1022    0.0466]); xlabel('Grid Space'); ylabel('GC'); xlim([min(MU_GC),max(MU_GC)]);
        title('Current estimate distribution')
        p=p+1;
        
        % Error
        subplot(M,N,p:p+1); p=p+2; hold off;
        plotvec = max([1,t-plothist]):max([2,t]);
        plot(plotvec,err(plotvec)); hold on;
        plot(plotvec,meanerr(plotvec)); ylim([0,L/2]); xlim([min(plotvec),max(plotvec)]);
        legend({'Err','Mean(Err)'},'Position',[0.6728    0.1552    0.0903    0.0394])
        title('Estimate error')
        
        set(gcf,'Position',1e3*[-0.3558    0.9058    1.1504    1.3168])
        drawnow

    end
    
end

%% 4. Output

% ...nothing here yet