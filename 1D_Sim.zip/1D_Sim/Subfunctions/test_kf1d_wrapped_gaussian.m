%% Test simple generation
hold on

MU = 0;
SIG = 0.0025;
L = 1/2;

X = -1:0.01:1;

F = kf1d_wrapped_gaussian(X,MU,SIG,L);

plot(X,F)
ylim([0,max(F)])
axis square

shg

%% Test PI updating
clearvars; %close all; clc

DX_PI = 0.005;
L = 1/2;
NGC = 500;
MU_GC = linspace(-L/2,L/2,NGC+1); MU_GC = MU_GC(1:end-1);
SIG_Q = (0.01*ones(1,NGC)).^2;

P_PI = kf1d_wrapped_gaussian(DX_PI,MU_GC,SIG_Q,L);
GC   = kf1d_wrapped_gaussian(0    ,MU_GC,SIG_Q,L);

X=0;
err=[];
X=[0];

T = 100;

for t=2:T    
    X(t)=mod(X(t-1)+DX_PI+L/2,L)-L/2;
    
    P_PId = [P_PI,P_PI,P_PI,P_PI(1)];
    GC = conv(GC,P_PId,'same');
    GC = GC/sum(GC);
    YLIM = [0,max(GC)];
    
    Xest = MU_GC(find(GC==max(GC),1));
    
    ERR = [mod(X(t)-Xest,L),-mod(Xest-X(t),L)];
    [~,IND] = min(abs(ERR));
    err(end+1) = ERR(IND);
    
end
    
    subplot(3,1,1); plot(MU_GC,P_PI); axis square; % ylim(YLIM);
    subplot(3,1,2); plot(MU_GC,GC  ); axis square; % ylim(YLIM);
    hold on
    plot([X(t),X(t)],[0,max(GC)],'r--')
    hold off
    drawnow; shg
    %pause
    
%end

subplot(3,1,3); plot(err); axis square
drawnow

%pause;

%% Test number of wraps
cla; clearvars; clc

WR = 0:1:10;
L = 1/2;
NGC = 100;
MU_GC = linspace(-L/2,L/2,NGC);
SIG_Q = 1*ones(1,NGC);

OFFS = L/2;

YLIM = [0,0];
for w=1:length(WR)
    GC = kf1d_wrapped_gaussian(OFFS,MU_GC,SIG_Q,L,WR(w));
    YLIM(2) = max([YLIM(2),max(GC(:))]);
    plot(MU_GC,GC)
    hold on
end
legstring={}; for w=WR; legstring{end+1}=num2str(w); end
legend(legstring)

ylim(YLIM)
xlim([-L/2,L/2])

shg
