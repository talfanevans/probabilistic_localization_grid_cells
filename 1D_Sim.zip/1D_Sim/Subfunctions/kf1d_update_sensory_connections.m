% Update the PC->GC connections

function [W,TH] = kf1d_update_sensory_connections(PC,GC,TH,LR,W)

% Get time constants
tau_w =  1/LR; % Learning time constant (inverse of learning-rate)
tau_Th = tau_w/100; % Must be > tau_w (see Dayan and Abbott, BCM rule

% Update weights
W = W + (1/tau_w) * bsxfun(@times,PC.*(PC-TH),GC(:));
W = W.*(W>0);

% Update threshold
TH = TH + (1/tau_Th) * (PC.^2 - TH);

end