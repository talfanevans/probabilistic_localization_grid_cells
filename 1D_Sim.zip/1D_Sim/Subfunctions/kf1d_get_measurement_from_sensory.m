% Get measurement input to GCs from PCs

function PC_MEAS = kf1d_get_measurement_from_sensory(PC,W)

PC_MEAS = bsxfun(@times,W,PC); % Get the input to each of the grid cells

PC_MEAS = sum(PC_MEAS,2); % Sum all PC inputs onto each GC

PC_MEAS = PC_MEAS / sum(PC_MEAS(:)); % Normalise

end