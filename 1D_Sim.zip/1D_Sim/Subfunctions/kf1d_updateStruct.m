% Recursively copy over the fields and subfields from an existing structure
% to a new structure
%
% In:
%
% newStrc : The structure containing the fields that will be copied over
% oldStrc : The structure that will be added to and/or overwritten
%
% Out:
%
% outStrc : The new structure produced by the overwriting and/or adding
%
% Options: (use as second argument in inverted commas)
%
% 'overwrite' : Copies all fields from newStrc to oldStrc, regardless of
%               whether they existed before
% 'noflags'   : The program will throw an error if there are fields in
%               newStrc that don't exist in oldStrct. 'noflags' turns this
%               behaviour off
%
% Talfan Evans 2017

function outStrc = kf1d_updateStruct(newStrc,oldStrc,varargin)

if ~isempty(newStrc)
    
    %% Overwrite default behaviour if required
    
    % Defaults
    opts.flag = 1;
    opts.overwrite = 0;
    
    % Parse additional arguments
    for arg=1:length(varargin)
        switch lower(varargin{arg})
            case 'noflags'
                opts.flag = 0;
            case 'overwrite'
                opts.overwrite = 1;
        end
    end
    
    %% Set the new subfields
    
    % Get a list of all the subfields in newStrc
    subcell = iter_over(newStrc);
    
    % Loop over the subfields and decide whether or not to add them to oldStrc
    outStrc = oldStrc;
    for sb = 1:length(subcell)
        eval(['val=newStrc.',subcell{sb},';'])
        outStrc = setsubfield(outStrc,subcell{sb},val,opts);
    end
    
else
    outStrc = oldStrc;
end

end

%% Recursive function for iterating over fields
function outcell = iter_over(instrc)
outcell = {};
FN = fieldnames(instrc);
for f=1:length(FN)
    if isstruct(instrc.(FN{f}))
        % Iter over
        tmp = iter_over(instrc.(FN{f}));
        for t=1:length(tmp)
            outcell{end+1}=[FN{f},'.',tmp{t}];
        end
    else
        % Do something else
        outcell{end+1}=FN{f};
    end
end

end

%% Set subfields of a structure
function outstrc = setsubfield(instrc,subfield,val,opts)

%% Loop over the subfields and add if necessary
sf = strsplit(subfield,'.');
sf = sf(cellfun(@(x)~isempty(x),sf));

% If not in overwrite mode, check whether the subfield exists in the old structure before adding
if ~opts.overwrite
    c=1;
    tmp = 'instrc';
    while eval(['isfield(',tmp,',''',sf{c},''')'])
        if c==length(sf)
            tmp = [tmp,'.',sf{c}];
            eval([tmp,'=val;'])
            c=c+1;
            break
        end
        
        tmp = [tmp,'.',sf{c}];
        
        c=c+1;
    end
    
    % If in overwrite mode, add the subfield regardless of whether it exists in
    % the old structure
else
    eval(['instrc',subfield,'=',num2str(val)])
end

%% If opted for, throw an error if the field doesnt belong to the old
% structure
if opts.flag && ~opts.overwrite
    if c<(length(sf)+1)
        error(sprintf(['The subfield: ''%s'' does not exist in the old structure.\n',...
            'To add all new subfields, use this function with the ''overwrite'' option.\n',...
            'To continue with only replacing existing subfields but without throwing this error, use this function with the ''noflags'' option.'],...
            subfield)); %#ok<SPERR>
    end
end

%% The outstrc is the new instrc!
outstrc = instrc;

end