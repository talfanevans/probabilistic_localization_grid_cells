% 1D Place cell response
%
% F is a mtrix with outputs of dimensions: [NX,NC]
%
% where NX and NX are the number of query points and cells, respectively

function F = kf1d_get_pc_firing(X,MU,SigSquared,FMAX)

% Check inputs
if all(size(MU)>1) ; error('MU must be a vector.\n');  end
if all(size(SigSquared)>1); error('SIG must be a vector.\n'); end
if ~all(size(SigSquared)==size(MU)); error('SIG and MU and must have the same length.\n'); end

% Initialise the paramaters
X   = repmat(X(:),[1,length(MU)]);
SigSquared = repmat(SigSquared(:)',[length(X),1]);
MU  = repmat(MU(:)',[length(X),1]);

% Main
F = FMAX .* exp(-((X-MU).^2)./(2*SigSquared));

end